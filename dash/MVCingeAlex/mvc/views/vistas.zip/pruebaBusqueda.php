<?php  session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="http://localhost/MVCingeAlex/mvc/controller/Controller.php?accion=registrosDelUsuario" method="post">
		<input type="submit" name="imprimir">
	</form>
</body>
</html>